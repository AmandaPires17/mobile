import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Provider as PaperProvider } from 'react-native-paper';

import Livros from './screens/Livros';
import Romance from './screens/Romance';
import Drama from './screens/Drama';
import Terror from './screens/Terror';
import Ficcao from './screens/Ficcao';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="Livros" component={Livros} />
          <Stack.Screen name="Romance" component={Romance} />
          <Stack.Screen name="Drama" component={Drama} />
          <Stack.Screen name="Terror" component={Terror} />
          <Stack.Screen name="Ficcao" component={Ficcao} />
        </Stack.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}